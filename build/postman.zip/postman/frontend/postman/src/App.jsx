import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import Postman from './components/postman'
import {Container} from 'react-bootstrap'

function App() {
  return (
    <>
         <Postman/>
    </>
  )
}

export default App
